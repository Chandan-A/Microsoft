package StepDefinitions;

import java.net.MalformedURLException;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.touch.TouchActions;

import PageFactory.ComposePage_PF;
import PageFactory.LoginPage_PF;
import Utils.Hooks;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	
	private AndroidDriver driver ;
	
	LoginPage_PF login ;
	ComposePage_PF compose;
	
	public LoginSteps() {
		System.out.println("Inside ");
		this.driver = (AndroidDriver) Hooks.getDriver();
	}
	
	@Given("user is on login page")
	public void user_is_on_login_page() throws MalformedURLException, InterruptedException {
			
		driver.get("https://outlokk.live.com/owa/");		
		System.out.println("Reached Outlook page......");		
		Thread.sleep(6000);
		
		login = new LoginPage_PF(driver);
	}

	@When("user enters (.*) and (.*)$")
	public void user_enters_username_and_password(String username,String password) throws InterruptedException {
		login.clickOnSignIn();
		login.enterUsername(username);
		login.enterPassword(password);		
	}

	@And("clicks on login button")
	public void clicks_on_login_button() {
		login.clickOnLogin();	
		driver.openNotifications();
		driver.findElement(By.partialLinkText("Copy OTP")).click();
		TouchActions ta = new TouchActions(driver);
		ta.longPress(driver.findElement(By.id("idTxtBx_SAOTCC_OTC")));

	}

	@Then("user is navigated to home page")
	public void user_is_navigated_to_home_page() {
		login.validateHomePage();
		
	}
	
	
	@Given("user is on Home screen")
	public void validateUserOnHomescreen() {
		login.validateHomePage();
	}
	
	@And("clicks on Compose email")
	public void clickOnComposeMail() {
	 compose = new ComposePage_PF(driver);
	 compose.clickOnComposeMail();
		
	}
	
	@When("user compose mail (.*) and (.*) and (.*)")
	public void composeAnEmail(String To, String Subject, String Mailbody) {
		compose.composeAnEmail(To, Subject, Mailbody);
		
	}
	
	@And("Clicks on Send email")
	public void clickOnSend() {
		compose.clickOnSendMail();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@When("user enters chandan.a@happiestminds.com and Something")
	public void user_enters_chandan_a_happiestminds_com_and_something() {
		
	}

}
