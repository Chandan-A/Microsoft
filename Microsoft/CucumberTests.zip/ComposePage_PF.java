package PageFactory;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ComposePage_PF {
	
	WebDriver driver;
	
	public ComposePage_PF(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this); // this = LoginPage_PF.class
		
//		AjaxElementLocatorFactory ajax = new AjaxElementLocatorFactory(driver, 30);
//		PageFactory.initElements(ajax, this);		
	}
	
	@FindBy(how = How.XPATH,using="//a[text()=\"compose mail\"]")
	@CacheLookup
	WebElement btn_ComposeMail;
	
	@FindBy(how = How.XPATH, using = "//i[text()=\"To\"]")
	WebElement txt_To;
	
	@FindBy(xpath="//input[@name=\"Cc\"]")
	@CacheLookup
	WebElement txt_Cc;
	
	@FindBy(id = "Bcc")
	WebElement txt_Bcc;
	
	@FindBy(xpath="//input[@name=\"Subject\"]")
	@CacheLookup
	WebElement txt_Subject;
	
	@FindBy(xpath="//input[@type=\"mailbody\"]")
	@CacheLookup
	WebElement txt_Mailbody;
	
	@FindBy(how = How.ID,using="attachamnetIcon")
	WebElement icon_Attachment;
	
	@FindBy(how = How.ID, using = "PictureIcon")
	WebElement icon_Picture;
	
	@FindBy(how = How.ID,using = "idSIButton9")
	WebElement btn_Send;
	
	@FindBy(xpath = "//div[text()=\"Inbox\"]")
	WebElement btn_Close;
	
//	=================================================================================================================
	
	public void clickOnComposeMail() {
		btn_ComposeMail.click();
	}
	
	public void composeAnEmail(String To, String Subject,String Mailbody) {
		txt_To.sendKeys(To);
		txt_Subject.sendKeys(Subject);
		txt_Mailbody.sendKeys(Mailbody);
	}
	
	public void enterCcAndBcc(String Cc,String Bcc) {
		txt_Cc.sendKeys(Cc);
		txt_Bcc.sendKeys(Bcc);		
	}
	
	public void clickOnSendMail() {
		btn_Send.click();
	}
	public void addAttachment() {
		icon_Attachment.click();
	}
	
	public void addPictureFromCam() {
		icon_Picture.click();
			
	}

}
