package PageFactory;


import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;

public class LoginPage_PF {
	
	WebDriver driver;
	
	public LoginPage_PF(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this); // this = LoginPage_PF.class
		
//		AjaxElementLocatorFactory ajax = new AjaxElementLocatorFactory(driver, 30);
//		PageFactory.initElements(ajax, this);		
	}
	
	@FindBy(how = How.ID,using="name")
	List<WebElement> list;
	
	@FindBy(how = How.XPATH,using="//a[text()=\"Sign in\"]")
	@CacheLookup
	WebElement btn_SignIn;
	
	@FindBy(how = How.XPATH, using = "//i[text()=\"Continue to Outlook sign-in\"]")
	WebElement continueToSignIn;
	
	@FindBy(xpath="//input[@name=\"loginfmt\"]")
	@CacheLookup
	WebElement txt_username;
	
	@FindBy(id = "idSIButton9")
	WebElement btn_Next;
	
	@FindBy(xpath="//input[@name=\"passwd\"]")
	@CacheLookup
	WebElement txt_password;
	
	@FindBy(xpath="//input[@type=\"submit\"]")
	@CacheLookup
	WebElement btn_Login;
	
	@FindBy(how = How.ID,using="idTxtBx_SAOTCC_OTC")
	WebElement txt_OTP;
	
	@FindBy(how = How.ID, using = "idSubmit_SAOTCC_Continue")
	WebElement btn_Verify;
	
	@FindBy(how = How.ID,using = "idSIButton9")
	WebElement btn_StaySignIn_Yes;
	
	@FindBy(xpath = "//div[text()=\"Inbox\"]")
	WebElement header_Inbox;
	
//	=================================================================================================================
	
	public void clickOnSignIn() {
		btn_SignIn.click();
		continueToSignIn.click();
	}
	
	public void enterUsername(String username) {
		txt_username.sendKeys(username);
		btn_Next.click();
	}
	
	public void enterPassword(String password) {
		txt_password.sendKeys(password);		
	}
	
	public void clickOnLogin() {
		btn_Login.click();
	}
	
	public void verifyOTP() {
		
			
	}
	
	public void validateHomePage() {
		header_Inbox.isDisplayed();
	}

}
