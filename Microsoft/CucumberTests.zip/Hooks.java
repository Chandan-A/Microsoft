package Utils;


import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.cucumber.java.Before;

public class Hooks {
	
	static WebDriver driver;
	
	@Before
	public void setTestEnvironment() throws MalformedURLException, InterruptedException {		
		System.out.println("Inside TEst environment");
		DesiredCapabilities dc = new DesiredCapabilities();		
		dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Galaxy S10");
		dc.setCapability(MobileCapabilityType.UDID, "RZ8M31EJTTN");
		dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
		dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		dc.setCapability("appWaitDuration", "30000");
		dc.setCapability("browserName", "Chrome");
				
		driver = new AndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"),dc);
		driver.manage().timeouts().implicitlyWait(30000, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30000, TimeUnit.SECONDS);
		System.out.println("Exiting test environemnt");
	}
	
	public static WebDriver getDriver() {
//		return null;
		System.out.println("Inside - get driver");
		return driver;
		
	}
}
	

